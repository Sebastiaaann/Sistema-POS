import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import KPICard from './components/KPICard';
import MovementsChart from './components/Charts';
import RecentMovements from './components/RecentMovements';
import InventoryList from './components/InventoryList';
import { MOCK_KPIS, MOCK_MOVEMENTS, CHART_DATA, MOCK_PRODUCTS } from './constants';
import { Product } from './types';

const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'inventory'>('dashboard');
  
  // Lifted state for products to allow adding new items
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);

  const handleNavigate = (view: string) => {
    setCurrentView(view as 'dashboard' | 'inventory');
    setSidebarOpen(false); // Close sidebar on mobile after navigation
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts(prevProducts => [newProduct, ...prevProducts]);
  };

  return (
    <div className="flex h-screen bg-[#F3F4F6] overflow-hidden">
      {/* Sidebar Navigation */}
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header */}
        <Header onMenuClick={() => setSidebarOpen(true)} />

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-8">
            
            {/* Conditional Rendering based on currentView */}
            {currentView === 'dashboard' ? (
              <>
                {/* Dashboard View */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Dashboard General</h1>
                    <p className="text-sm text-gray-500 mt-1">Bienvenido de nuevo, aquí tienes el resumen de hoy.</p>
                  </div>
                  <div className="flex gap-3">
                     <button className="px-4 py-2 bg-white border border-gray-200 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors shadow-sm">
                       Exportar
                     </button>
                     <button className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm shadow-blue-200">
                       + Nuevo Movimiento
                     </button>
                  </div>
                </div>

                {/* KPI Section */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                  {MOCK_KPIS.map((kpi, index) => (
                    <KPICard key={index} data={kpi} index={index} />
                  ))}
                </div>

                {/* Charts & Lists Section */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Main Chart (2/3 width on large screens) */}
                  <div className="lg:col-span-2 h-[400px]">
                    <MovementsChart data={CHART_DATA} />
                  </div>

                  {/* Recent List (1/3 width on large screens) */}
                  <div className="lg:col-span-1 h-[400px]">
                    <RecentMovements movements={MOCK_MOVEMENTS} />
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Inventory View */}
                <div className="h-[calc(100vh-140px)]">
                  <InventoryList products={products} onAddProduct={handleAddProduct} />
                </div>
              </>
            )}

          </div>
        </main>
      </div>
    </div>
  );
};

export default App;