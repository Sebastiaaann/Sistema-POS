import { ChartDataPoint, KPIData, Movement, Product } from './types';

export const MOCK_KPIS: KPIData[] = [
  {
    label: "Valor Total Inventario",
    value: "$124,500.00",
    trend: "up",
    trendValue: "+12%"
  },
  {
    label: "Productos Bajo Stock",
    value: 12,
    alert: true,
    subValue: "Stock < 10 items"
  },
  {
    label: "Movimientos Hoy",
    value: 45,
    subValue: "+15 Entradas, -30 Salidas"
  },
  {
    label: "Margen Estimado",
    value: "22%",
    color: "text-emerald-600",
    trend: "up",
    trendValue: "+2.4%"
  }
];

export const MOCK_MOVEMENTS: Movement[] = [
  {
    id: '1',
    type: 'out',
    productName: 'Laptop Dell XPS 15',
    sku: 'DELL-XPS-15',
    quantity: -2,
    userName: 'Carlos Ruiz',
    userAvatar: 'https://picsum.photos/32/32?random=1',
    timestamp: 'Hace 5 min'
  },
  {
    id: '2',
    type: 'in',
    productName: 'Monitor Samsung 27"',
    sku: 'SAM-MON-27',
    quantity: 15,
    userName: 'Ana Garcia',
    userAvatar: 'https://picsum.photos/32/32?random=2',
    timestamp: 'Hace 24 min'
  },
  {
    id: '3',
    type: 'out',
    productName: 'Teclado Mecánico Keychron',
    sku: 'KEY-K2-V2',
    quantity: -1,
    userName: 'Carlos Ruiz',
    userAvatar: 'https://picsum.photos/32/32?random=1',
    timestamp: 'Hace 1 hora'
  },
  {
    id: '4',
    type: 'adjustment',
    productName: 'Mouse Logitech MX',
    sku: 'LOG-MX-3',
    quantity: -3,
    userName: 'Admin User',
    userAvatar: 'https://picsum.photos/32/32?random=3',
    timestamp: 'Hace 2 horas'
  },
  {
    id: '5',
    type: 'in',
    productName: 'Stand Laptop Aluminio',
    sku: 'ACC-STD-01',
    quantity: 50,
    userName: 'Ana Garcia',
    userAvatar: 'https://picsum.photos/32/32?random=2',
    timestamp: 'Hace 3 horas'
  }
];

export const CHART_DATA: ChartDataPoint[] = [
  { name: '01 Nov', entradas: 40, salidas: 24 },
  { name: '05 Nov', entradas: 30, salidas: 13 },
  { name: '10 Nov', entradas: 20, salidas: 58 },
  { name: '15 Nov', entradas: 27, salidas: 39 },
  { name: '20 Nov', entradas: 18, salidas: 48 },
  { name: '25 Nov', entradas: 23, salidas: 38 },
  { name: '30 Nov', entradas: 34, salidas: 43 },
];

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Laptop Dell XPS 15',
    sku: 'DELL-XPS-15',
    category: 'Electrónica',
    stock: 8,
    minStock: 10,
    price: 1850.00,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=100'
  },
  {
    id: '2',
    name: 'Monitor Samsung 27" 4K',
    sku: 'SAM-MON-27',
    category: 'Periféricos',
    stock: 45,
    minStock: 15,
    price: 350.00,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=101'
  },
  {
    id: '3',
    name: 'Teclado Mecánico Keychron K2',
    sku: 'KEY-K2-V2',
    category: 'Periféricos',
    stock: 120,
    minStock: 30,
    price: 95.00,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=102'
  },
  {
    id: '4',
    name: 'Mouse Logitech MX Master 3',
    sku: 'LOG-MX-3',
    category: 'Periféricos',
    stock: 5,
    minStock: 20,
    price: 99.99,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=103'
  },
  {
    id: '5',
    name: 'Stand Laptop Aluminio',
    sku: 'ACC-STD-01',
    category: 'Accesorios',
    stock: 200,
    minStock: 50,
    price: 45.00,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=104'
  },
  {
    id: '6',
    name: 'Cable HDMI 2.1 2m',
    sku: 'CBL-HDMI-2',
    category: 'Cables',
    stock: 0,
    minStock: 50,
    price: 15.50,
    status: 'inactive',
    image: 'https://picsum.photos/64/64?random=105'
  },
  {
    id: '7',
    name: 'Silla Ergonómica Pro',
    sku: 'FUR-CHR-01',
    category: 'Mobiliario',
    stock: 12,
    minStock: 5,
    price: 450.00,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=106'
  },
  {
    id: '8',
    name: 'Webcam Logitech C920',
    sku: 'LOG-WEB-C920',
    category: 'Periféricos',
    stock: 28,
    minStock: 10,
    price: 79.99,
    status: 'active',
    image: 'https://picsum.photos/64/64?random=107'
  }
];